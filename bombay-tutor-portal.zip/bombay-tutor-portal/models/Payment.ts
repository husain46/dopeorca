import mongoose, { Document, Model } from 'mongoose'

export interface IPayment extends Document {
  userId: mongoose.Types.ObjectId
  requirementId: mongoose.Types.ObjectId
  razorpayOrderId: string
  razorpayPaymentId?: string
  razorpaySignature?: string
  amount: number
  status: 'created' | 'paid' | 'failed'
  createdAt: Date
  updatedAt: Date
}

const paymentSchema = new mongoose.Schema<IPayment>(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    requirementId: { type: mongoose.Schema.Types.ObjectId, ref: 'StudentRequirement', required: true },
    razorpayOrderId: { type: String, required: true },
    razorpayPaymentId: { type: String },
    razorpaySignature: { type: String },
    amount: { type: Number, required: true },
    status: { type: String, enum: ['created', 'paid', 'failed'], default: 'created' },
  },
  { timestamps: true }
)

const Payment: Model<IPayment> =
  mongoose.models.Payment || mongoose.model<IPayment>('Payment', paymentSchema)

export default Payment
