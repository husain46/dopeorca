import mongoose, { Document, Model } from 'mongoose'

export interface ITeacherProfile extends Document {
  userId: mongoose.Types.ObjectId
  subjects: string[]
  classes: string[]
  areas: string[]
  experience: number
  fees: number
  teachingMode: 'Home Visit' | 'Online' | 'Both'
  bio: string
  qualification: string
  gender?: string
  profilePhoto?: string
  unlockedRequirements: mongoose.Types.ObjectId[]
  createdAt: Date
  updatedAt: Date
}

const teacherProfileSchema = new mongoose.Schema<ITeacherProfile>(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
    subjects: [{ type: String }],
    classes: [{ type: String }],
    areas: [{ type: String }],
    experience: { type: Number, default: 0 },
    fees: { type: Number, default: 0 },
    teachingMode: { type: String, enum: ['Home Visit', 'Online', 'Both'], default: 'Both' },
    bio: { type: String, default: '' },
    qualification: { type: String, default: '' },
    gender: { type: String, enum: ['Male', 'Female', 'Other'] },
    profilePhoto: { type: String },
    unlockedRequirements: [{ type: mongoose.Schema.Types.ObjectId, ref: 'StudentRequirement' }],
  },
  { timestamps: true }
)

const TeacherProfile: Model<ITeacherProfile> =
  mongoose.models.TeacherProfile || mongoose.model<ITeacherProfile>('TeacherProfile', teacherProfileSchema)

export default TeacherProfile
