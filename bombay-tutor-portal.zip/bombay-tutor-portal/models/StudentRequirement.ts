import mongoose, { Document, Model } from 'mongoose'

export interface IStudentRequirement extends Document {
  userId: mongoose.Types.ObjectId
  subject: string
  class: string
  area: string
  budget: number
  contact: string
  name: string
  description?: string
  teachingMode?: string
  isActive: boolean
  createdAt: Date
  updatedAt: Date
}

const studentRequirementSchema = new mongoose.Schema<IStudentRequirement>(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    subject: { type: String, required: true },
    class: { type: String, required: true },
    area: { type: String, required: true },
    budget: { type: Number, required: true },
    contact: { type: String, required: true },
    name: { type: String, required: true },
    description: { type: String },
    teachingMode: { type: String },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
)

const StudentRequirement: Model<IStudentRequirement> =
  mongoose.models.StudentRequirement ||
  mongoose.model<IStudentRequirement>('StudentRequirement', studentRequirementSchema)

export default StudentRequirement
