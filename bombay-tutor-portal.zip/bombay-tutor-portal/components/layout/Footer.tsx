import Link from 'next/link'
import { GraduationCap, Phone, Mail, MapPin } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="bg-blue-950 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 rounded-lg bg-orange-500 flex items-center justify-center">
                <GraduationCap className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="font-display font-bold text-white">Bombay Home Tutors</div>
              </div>
            </div>
            <p className="text-blue-200 text-sm leading-relaxed">
              Mumbai&apos;s trusted tutor marketplace connecting students with qualified home tutors across the city.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-white mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm text-blue-200">
              <li><Link href="/tutors" className="hover:text-orange-400 transition-colors">Find Tutors</Link></li>
              <li><Link href="/post-requirement" className="hover:text-orange-400 transition-colors">Post Requirement</Link></li>
              <li><Link href="/register" className="hover:text-orange-400 transition-colors">Register as Tutor</Link></li>
              <li><Link href="/login" className="hover:text-orange-400 transition-colors">Login</Link></li>
            </ul>
          </div>

          {/* Areas */}
          <div>
            <h4 className="font-semibold text-white mb-4">Areas We Cover</h4>
            <ul className="space-y-2 text-sm text-blue-200">
              <li>Andheri, Bandra, Dadar</li>
              <li>Thane, Borivali, Malad</li>
              <li>Vashi, Panvel, Navi Mumbai</li>
              <li>Kurla, Ghatkopar, Vikhroli</li>
              <li>Virar, Vasai, Badlapur</li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-semibold text-white mb-4">Contact</h4>
            <ul className="space-y-3 text-sm text-blue-200">
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-orange-400 shrink-0" />
                <span>info@bombayhometutors.com</span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-orange-400 shrink-0" />
                <span>+91 98765 43210</span>
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-orange-400 shrink-0" />
                <span>Mumbai, Maharashtra</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-blue-800 mt-10 pt-6 flex flex-col sm:flex-row justify-between items-center gap-2 text-xs text-blue-300">
          <p>© {new Date().getFullYear()} Bombay Home Tutors. All rights reserved.</p>
          <p>Made with ❤️ for Mumbai students</p>
        </div>
      </div>
    </footer>
  )
}
