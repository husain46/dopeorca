'use client'

import Link from 'next/link'
import { useSession, signOut } from 'next-auth/react'
import { useState } from 'react'
import { Menu, X, GraduationCap, ChevronDown } from 'lucide-react'
import { cn } from '@/lib/utils'

export default function Navbar() {
  const { data: session } = useSession()
  const [menuOpen, setMenuOpen] = useState(false)
  const user = session?.user as any

  const getDashboardLink = () => {
    if (!user) return null
    if (user.role === 'admin') return '/admin/dashboard'
    if (user.role === 'teacher') return '/dashboard'
    return '/student'
  }

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-orange-100 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-orange-500 to-blue-800 flex items-center justify-center shadow-md group-hover:shadow-orange-200 transition-shadow">
              <GraduationCap className="w-5 h-5 text-white" />
            </div>
            <div className="hidden sm:block">
              <span className="font-display font-bold text-blue-900 text-lg leading-tight block">
                Bombay
              </span>
              <span className="text-xs text-orange-500 font-medium -mt-1 block leading-tight">
                Home Tutors
              </span>
            </div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/tutors" className="text-sm font-medium text-gray-600 hover:text-orange-600 transition-colors">
              Find Tutors
            </Link>
            <Link href="/post-requirement" className="text-sm font-medium text-gray-600 hover:text-orange-600 transition-colors">
              Post Requirement
            </Link>
            {session ? (
              <>
                <Link
                  href={getDashboardLink()!}
                  className="text-sm font-medium text-gray-600 hover:text-orange-600 transition-colors"
                >
                  Dashboard
                </Link>
                <button
                  onClick={() => signOut({ callbackUrl: '/' })}
                  className="text-sm font-medium text-gray-500 hover:text-red-500 transition-colors"
                >
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link href="/login" className="text-sm font-medium text-gray-600 hover:text-orange-600 transition-colors">
                  Login
                </Link>
                <Link
                  href="/register"
                  className="bg-orange-500 hover:bg-orange-600 text-white text-sm font-semibold px-4 py-2 rounded-lg transition-colors shadow-sm"
                >
                  Register Free
                </Link>
              </>
            )}
          </nav>

          {/* Mobile menu button */}
          <button
            className="md:hidden p-2 rounded-lg text-gray-600 hover:bg-gray-100"
            onClick={() => setMenuOpen(!menuOpen)}
          >
            {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="md:hidden bg-white border-t border-gray-100 px-4 py-3 space-y-2">
          <Link href="/tutors" className="block py-2 text-sm font-medium text-gray-700" onClick={() => setMenuOpen(false)}>Find Tutors</Link>
          <Link href="/post-requirement" className="block py-2 text-sm font-medium text-gray-700" onClick={() => setMenuOpen(false)}>Post Requirement</Link>
          {session ? (
            <>
              <Link href={getDashboardLink()!} className="block py-2 text-sm font-medium text-gray-700" onClick={() => setMenuOpen(false)}>Dashboard</Link>
              <button onClick={() => { signOut({ callbackUrl: '/' }); setMenuOpen(false) }} className="block w-full text-left py-2 text-sm font-medium text-red-500">Logout</button>
            </>
          ) : (
            <>
              <Link href="/login" className="block py-2 text-sm font-medium text-gray-700" onClick={() => setMenuOpen(false)}>Login</Link>
              <Link href="/register" className="block py-2 text-sm font-semibold text-orange-600" onClick={() => setMenuOpen(false)}>Register Free</Link>
            </>
          )}
        </div>
      )}
    </header>
  )
}
