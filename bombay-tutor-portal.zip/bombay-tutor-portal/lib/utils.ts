import { type ClassValue, clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export const MUMBAI_AREAS = [
  'CST',
  'Churchgate',
  'Marine Lines',
  'Grant Road',
  'Mumbai Central',
  'Dadar',
  'Matunga',
  'Sion',
  'Kurla',
  'Ghatkopar',
  'Vikhroli',
  'Kanjur Marg',
  'Bhandup',
  'Mulund',
  'Thane',
  'Kalwa',
  'Dombivli',
  'Kalyan',
  'Badlapur',
  'Andheri',
  'Jogeshwari',
  'Goregaon',
  'Malad',
  'Kandivali',
  'Borivali',
  'Dahisar',
  'Bandra',
  'Khar',
  'Santacruz',
  'Vile Parle',
  'Juhu',
  'Vashi',
  'Nerul',
  'Belapur',
  'Panvel',
  'Kharghar',
  'Ulwe',
  'Virar',
  'Vasai',
  'Nalasopara',
]

export const SUBJECTS = [
  'Mathematics',
  'Science',
  'Physics',
  'Chemistry',
  'Biology',
  'English',
  'Hindi',
  'Marathi',
  'History',
  'Geography',
  'Social Science',
  'Computer Science',
  'Economics',
  'Accountancy',
  'Business Studies',
  'Sanskrit',
  'French',
  'German',
  'Music',
  'Drawing & Painting',
  'Physical Education',
  'EVS',
  'General Knowledge',
  'Coding / Programming',
  'Spoken English',
]

export const CLASSES = [
  'Nursery',
  'KG',
  'Class 1',
  'Class 2',
  'Class 3',
  'Class 4',
  'Class 5',
  'Class 6',
  'Class 7',
  'Class 8',
  'Class 9',
  'Class 10',
  'Class 11',
  'Class 12',
  'Graduation',
  'Post Graduation',
  'Competitive Exams',
  'NEET',
  'JEE',
  'CA Foundation',
  'CA Intermediate',
]

export const TEACHING_MODES = ['Home Visit', 'Online', 'Both']

export const UNLOCK_FEE = 500

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 0,
  }).format(amount)
}

export function formatDate(date: Date | string): string {
  return new Date(date).toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  })
}
