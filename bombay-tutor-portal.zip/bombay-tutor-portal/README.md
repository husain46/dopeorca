# Bombay Home Tutors Portal

Mumbai's tutor marketplace — connect students with verified home tutors across Mumbai, Thane, and Navi Mumbai.

## Tech Stack

- **Next.js 14** (App Router)
- **TypeScript**
- **MongoDB + Mongoose**
- **NextAuth** (email/password)
- **Razorpay** payment integration
- **TailwindCSS + shadcn/ui**

---

## Quick Start

### 1. Clone & install

```bash
cd bombay-tutor-portal
npm install
```

### 2. Configure environment

```bash
cp .env.example .env.local
```

Edit `.env.local`:

```env
MONGODB_URI=mongodb://localhost:27017/bombay-tutor-portal
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=some-long-random-string-here

RAZORPAY_KEY_ID=rzp_test_xxxxxxxxxxxx
RAZORPAY_KEY_SECRET=xxxxxxxxxxxxxxxxxxxx
NEXT_PUBLIC_RAZORPAY_KEY_ID=rzp_test_xxxxxxxxxxxx

ADMIN_EMAIL=admin@bombayhometutors.com
ADMIN_PASSWORD=Admin@123456

NEXT_PUBLIC_APP_URL=http://localhost:3000
UNLOCK_FEE=500
```

### 3. Seed the admin user

```bash
node scripts/seed.js
```

### 4. Start the dev server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

---

## Pages

| URL | Description |
|-----|-------------|
| `/` | Homepage |
| `/tutors` | Tutor search & listing |
| `/tutor/[id]` | Individual tutor profile |
| `/post-requirement` | Post a requirement (public) |
| `/login` | User login |
| `/register` | User registration |
| `/dashboard` | Teacher dashboard overview |
| `/dashboard/profile` | Edit teacher profile |
| `/dashboard/requirements` | Browse & unlock student requirements |
| `/dashboard/payment` | Teacher payment history |
| `/student` | Student dashboard |
| `/student/post` | Post a requirement (student) |
| `/student/requirements` | View my requirements |
| `/admin/login` | Admin login |
| `/admin/dashboard` | Admin panel (users, payments, requirements) |

---

## User Roles

| Role | Access |
|------|--------|
| **student** | Post requirements, browse tutors |
| **teacher** | Create profile, view & unlock requirements (₹500 via Razorpay) |
| **admin** | Approve teachers, manage all users, view all data |

---

## Razorpay Setup

1. Create a [Razorpay account](https://razorpay.com)
2. Go to Settings → API Keys → Generate Test Key
3. Add `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET` to `.env.local`
4. For production, use live keys and update `NEXTAUTH_URL`

---

## Project Structure

```
bombay-tutor-portal/
├── app/
│   ├── api/               # API routes
│   │   ├── auth/          # NextAuth + register
│   │   ├── tutors/        # Tutor CRUD + profile
│   │   ├── requirements/  # Student requirements
│   │   ├── payments/      # Razorpay create-order + verify
│   │   └── admin/         # Admin user management + stats
│   ├── admin/             # Admin pages
│   ├── dashboard/         # Teacher dashboard
│   ├── student/           # Student dashboard
│   ├── tutors/            # Public tutor listing
│   ├── tutor/[id]/        # Public tutor profile
│   ├── post-requirement/  # Public requirement form
│   ├── login/
│   ├── register/
│   ├── layout.tsx
│   └── page.tsx           # Homepage
├── components/
│   ├── layout/            # Navbar, Footer, SessionProvider
│   └── ui/                # shadcn/ui components
├── lib/
│   ├── auth.ts            # NextAuth config
│   ├── dbConnect.ts       # MongoDB connection
│   ├── razorpay.ts        # Razorpay client
│   └── utils.ts           # Helpers, constants
├── models/
│   ├── User.ts
│   ├── TeacherProfile.ts
│   ├── StudentRequirement.ts
│   └── Payment.ts
├── scripts/
│   └── seed.js            # Admin seed script
└── .env.example
```

---

## License

MIT — feel free to use and modify for your own projects.
