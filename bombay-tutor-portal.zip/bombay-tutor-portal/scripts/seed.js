/**
 * Run with:  node scripts/seed.js
 * Creates the admin user using ADMIN_EMAIL and ADMIN_PASSWORD from .env.local
 */

require('dotenv').config({ path: '.env.local' })
const mongoose = require('mongoose')
const bcrypt = require('bcryptjs')

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/bombay-tutor-portal'
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'admin@bombayhometutors.com'
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'Admin@123456'

async function seed() {
  await mongoose.connect(MONGODB_URI)
  console.log('Connected to MongoDB')

  const UserSchema = new mongoose.Schema({
    name: String,
    email: { type: String, unique: true, lowercase: true },
    password: String,
    role: String,
    isApproved: Boolean,
  }, { timestamps: true })

  const User = mongoose.models.User || mongoose.model('User', UserSchema)

  const existing = await User.findOne({ email: ADMIN_EMAIL })
  if (existing) {
    console.log('Admin already exists:', ADMIN_EMAIL)
    process.exit(0)
  }

  const hashed = await bcrypt.hash(ADMIN_PASSWORD, 12)
  await User.create({
    name: 'Admin',
    email: ADMIN_EMAIL,
    password: hashed,
    role: 'admin',
    isApproved: true,
  })

  console.log('✅ Admin created:', ADMIN_EMAIL)
  console.log('🔑 Password:', ADMIN_PASSWORD)
  process.exit(0)
}

seed().catch((err) => { console.error(err); process.exit(1) })
