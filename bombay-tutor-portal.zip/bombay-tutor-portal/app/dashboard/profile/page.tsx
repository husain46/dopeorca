'use client'

import { useState, useEffect } from 'react'
import { Loader2, Save, CheckCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { SUBJECTS, MUMBAI_AREAS, CLASSES, TEACHING_MODES } from '@/lib/utils'

export default function TeacherProfilePage() {
  const [profile, setProfile] = useState<any>({
    subjects: [], classes: [], areas: [], experience: 0,
    fees: 0, teachingMode: 'Both', bio: '', qualification: '', gender: '',
  })
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    fetch('/api/tutors/profile')
      .then((r) => r.json())
      .then((data) => {
        if (data.profile) setProfile(data.profile)
        setLoading(false)
      })
      .catch(() => setLoading(false))
  }, [])

  const toggleItem = (field: 'subjects' | 'classes' | 'areas', value: string) => {
    setProfile((prev: any) => ({
      ...prev,
      [field]: prev[field].includes(value)
        ? prev[field].filter((v: string) => v !== value)
        : [...prev[field], value],
    }))
  }

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true)
    setError('')
    const res = await fetch('/api/tutors/profile', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(profile),
    })
    const data = await res.json()
    setSaving(false)
    if (!res.ok) { setError(data.error || 'Failed to save'); return }
    setSaved(true)
    setTimeout(() => setSaved(false), 3000)
  }

  if (loading) return (
    <div className="flex items-center justify-center py-20">
      <Loader2 className="w-8 h-8 animate-spin text-orange-500" />
    </div>
  )

  return (
    <div className="p-6 max-w-3xl">
      <div className="mb-6">
        <h1 className="font-display text-2xl font-bold text-blue-950">Edit Profile</h1>
        <p className="text-gray-500 mt-1">Complete your profile to attract more students.</p>
      </div>

      {error && <div className="bg-red-50 border border-red-200 text-red-700 rounded-lg px-4 py-3 text-sm mb-5">{error}</div>}
      {saved && (
        <div className="bg-green-50 border border-green-200 text-green-700 rounded-lg px-4 py-3 text-sm mb-5 flex items-center gap-2">
          <CheckCircle className="w-4 h-4" /> Profile saved successfully!
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-6">
        {/* Basic Info */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 space-y-4">
          <h2 className="font-display font-semibold text-blue-950">Basic Information</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Qualification</Label>
              <Input placeholder="e.g. B.Sc Mathematics, IIT Bombay" value={profile.qualification} onChange={(e) => setProfile({ ...profile, qualification: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label>Years of Experience</Label>
              <Input type="number" min={0} value={profile.experience} onChange={(e) => setProfile({ ...profile, experience: Number(e.target.value) })} />
            </div>
            <div className="space-y-1.5">
              <Label>Hourly Fees (₹)</Label>
              <Input type="number" min={0} placeholder="e.g. 500" value={profile.fees} onChange={(e) => setProfile({ ...profile, fees: Number(e.target.value) })} />
            </div>
            <div className="space-y-1.5">
              <Label>Teaching Mode</Label>
              <Select value={profile.teachingMode} onValueChange={(v) => setProfile({ ...profile, teachingMode: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{TEACHING_MODES.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Gender</Label>
              <Select value={profile.gender || ''} onValueChange={(v) => setProfile({ ...profile, gender: v })}>
                <SelectTrigger><SelectValue placeholder="Select gender" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Male">Male</SelectItem>
                  <SelectItem value="Female">Female</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>Bio / About You</Label>
            <Textarea placeholder="Tell students about your teaching experience, methodology, and achievements..." value={profile.bio} onChange={(e) => setProfile({ ...profile, bio: e.target.value })} rows={4} />
          </div>
        </div>

        {/* Subjects */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
          <h2 className="font-display font-semibold text-blue-950 mb-1">Subjects You Teach</h2>
          <p className="text-sm text-gray-500 mb-4">Selected: {profile.subjects.length}</p>
          <div className="flex flex-wrap gap-2">
            {SUBJECTS.map((s) => (
              <button
                key={s} type="button"
                onClick={() => toggleItem('subjects', s)}
                className={`px-3 py-1.5 rounded-full text-sm font-medium border transition-all ${
                  profile.subjects.includes(s)
                    ? 'bg-orange-500 text-white border-orange-500'
                    : 'bg-white text-gray-600 border-gray-200 hover:border-orange-300'
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Classes */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
          <h2 className="font-display font-semibold text-blue-950 mb-1">Classes You Teach</h2>
          <p className="text-sm text-gray-500 mb-4">Selected: {profile.classes.length}</p>
          <div className="flex flex-wrap gap-2">
            {CLASSES.map((c) => (
              <button
                key={c} type="button"
                onClick={() => toggleItem('classes', c)}
                className={`px-3 py-1.5 rounded-full text-sm font-medium border transition-all ${
                  profile.classes.includes(c)
                    ? 'bg-blue-900 text-white border-blue-900'
                    : 'bg-white text-gray-600 border-gray-200 hover:border-blue-300'
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        {/* Areas */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
          <h2 className="font-display font-semibold text-blue-950 mb-1">Teaching Areas</h2>
          <p className="text-sm text-gray-500 mb-4">Selected: {profile.areas.length}</p>
          <div className="flex flex-wrap gap-2">
            {MUMBAI_AREAS.map((a) => (
              <button
                key={a} type="button"
                onClick={() => toggleItem('areas', a)}
                className={`px-3 py-1.5 rounded-full text-sm font-medium border transition-all ${
                  profile.areas.includes(a)
                    ? 'bg-green-600 text-white border-green-600'
                    : 'bg-white text-gray-600 border-gray-200 hover:border-green-300'
                }`}
              >
                {a}
              </button>
            ))}
          </div>
        </div>

        <Button type="submit" size="lg" className="w-full" disabled={saving}>
          {saving ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Saving...</> : <><Save className="w-4 h-4 mr-2" /> Save Profile</>}
        </Button>
      </form>
    </div>
  )
}
