'use client'

import { useState, useEffect } from 'react'
import { Loader2, CheckCircle, XCircle, Clock } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { formatCurrency, formatDate } from '@/lib/utils'

interface Payment {
  _id: string
  razorpayOrderId: string
  razorpayPaymentId?: string
  amount: number
  status: 'created' | 'paid' | 'failed'
  createdAt: string
  requirementId?: { subject: string; class: string; area: string }
}

export default function PaymentPage() {
  const [payments, setPayments] = useState<Payment[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/payments')
      .then((r) => r.json())
      .then((data) => { setPayments(data.payments || []); setLoading(false) })
      .catch(() => setLoading(false))
  }, [])

  const statusIcon = (status: string) => {
    if (status === 'paid') return <CheckCircle className="w-4 h-4 text-green-600" />
    if (status === 'failed') return <XCircle className="w-4 h-4 text-red-500" />
    return <Clock className="w-4 h-4 text-yellow-500" />
  }

  const statusBadge = (status: string) => {
    if (status === 'paid') return <Badge variant="success">Paid</Badge>
    if (status === 'failed') return <Badge variant="destructive">Failed</Badge>
    return <Badge variant="warning">Pending</Badge>
  }

  const total = payments.filter((p) => p.status === 'paid').reduce((sum, p) => sum + p.amount, 0)

  return (
    <div className="p-6 max-w-4xl">
      <div className="mb-6">
        <h1 className="font-display text-2xl font-bold text-blue-950">Payment History</h1>
        <p className="text-gray-500 mt-1">Track all your requirement unlock payments.</p>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
        {[
          { label: 'Total Spent', value: formatCurrency(total), color: 'text-blue-950' },
          { label: 'Successful', value: payments.filter((p) => p.status === 'paid').length, color: 'text-green-600' },
          { label: 'Total Unlocks', value: payments.filter((p) => p.status === 'paid').length, color: 'text-orange-600' },
        ].map((stat) => (
          <div key={stat.label} className="bg-white rounded-xl border border-gray-100 shadow-sm p-5 text-center">
            <p className={`font-display text-2xl font-bold ${stat.color}`}>{stat.value}</p>
            <p className="text-gray-500 text-sm">{stat.label}</p>
          </div>
        ))}
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-8 h-8 animate-spin text-orange-500" />
        </div>
      ) : payments.length === 0 ? (
        <div className="text-center py-16 text-gray-400">
          <Clock className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p className="font-medium">No payment history yet.</p>
          <p className="text-sm mt-1">Unlock a student requirement to get started.</p>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-100">
                <tr>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Date</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Requirement</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Amount</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Status</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Payment ID</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {payments.map((payment) => (
                  <tr key={payment._id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-5 py-4 text-sm text-gray-600">{formatDate(payment.createdAt)}</td>
                    <td className="px-5 py-4 text-sm text-gray-700">
                      {payment.requirementId ? (
                        <span>{payment.requirementId.subject} · {payment.requirementId.class} · {payment.requirementId.area}</span>
                      ) : (
                        <span className="text-gray-400">—</span>
                      )}
                    </td>
                    <td className="px-5 py-4 text-sm font-semibold text-blue-950">{formatCurrency(payment.amount)}</td>
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-1.5">
                        {statusIcon(payment.status)}
                        {statusBadge(payment.status)}
                      </div>
                    </td>
                    <td className="px-5 py-4 text-xs text-gray-400 font-mono truncate max-w-[140px]">
                      {payment.razorpayPaymentId || payment.razorpayOrderId}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}
