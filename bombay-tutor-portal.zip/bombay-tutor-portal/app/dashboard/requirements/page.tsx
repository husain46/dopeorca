'use client'

import { useState, useEffect } from 'react'
import { Loader2, Lock, Unlock, Phone, User, MapPin, BookOpen, IndianRupee, Filter } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { formatCurrency, formatDate, SUBJECTS, MUMBAI_AREAS, UNLOCK_FEE } from '@/lib/utils'
import { toast } from '@/components/ui/use-toast'

declare global { interface Window { Razorpay: any } }

interface Requirement {
  _id: string
  subject: string
  class: string
  area: string
  budget: number
  teachingMode?: string
  description?: string
  createdAt: string
  isUnlocked: boolean
  contact: string | null
  name: string | null
}

export default function TeacherRequirementsPage() {
  const [requirements, setRequirements] = useState<Requirement[]>([])
  const [loading, setLoading] = useState(true)
  const [unlocking, setUnlocking] = useState<string | null>(null)
  const [subjectFilter, setSubjectFilter] = useState('')
  const [areaFilter, setAreaFilter] = useState('')

  const fetchRequirements = async () => {
    setLoading(true)
    const params = new URLSearchParams()
    if (subjectFilter) params.set('subject', subjectFilter)
    if (areaFilter) params.set('area', areaFilter)
    const res = await fetch(`/api/requirements?${params}`)
    const data = await res.json()
    setRequirements(data.requirements || [])
    setLoading(false)
  }

  useEffect(() => { fetchRequirements() }, [subjectFilter, areaFilter]) // eslint-disable-line react-hooks/exhaustive-deps

  const handleUnlock = async (requirementId: string) => {
    setUnlocking(requirementId)
    try {
      // Load Razorpay script
      if (!window.Razorpay) {
        await new Promise<void>((resolve, reject) => {
          const script = document.createElement('script')
          script.src = 'https://checkout.razorpay.com/v1/checkout.js'
          script.onload = () => resolve()
          script.onerror = () => reject(new Error('Razorpay script failed'))
          document.body.appendChild(script)
        })
      }

      const orderRes = await fetch('/api/payments/create-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ requirementId }),
      })
      const orderData = await orderRes.json()
      if (!orderRes.ok) throw new Error(orderData.error || 'Failed to create order')

      const options = {
        key: orderData.key,
        amount: orderData.amount,
        currency: orderData.currency,
        name: 'Bombay Home Tutors',
        description: 'Unlock student requirement',
        order_id: orderData.orderId,
        handler: async (response: any) => {
          const verifyRes = await fetch('/api/payments/verify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              razorpay_order_id: response.razorpay_order_id,
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_signature: response.razorpay_signature,
              requirementId,
            }),
          })
          const verifyData = await verifyRes.json()
          if (verifyRes.ok) {
            toast({ title: '✓ Unlocked!', description: 'You can now view the student contact details.', variant: 'success' as any })
            fetchRequirements()
          } else {
            toast({ title: 'Verification failed', description: verifyData.error, variant: 'destructive' })
          }
          setUnlocking(null)
        },
        modal: { ondismiss: () => setUnlocking(null) },
        prefill: {},
        theme: { color: '#f97316' },
      }
      const rzp = new window.Razorpay(options)
      rzp.open()
    } catch (err: any) {
      toast({ title: 'Error', description: err.message, variant: 'destructive' })
      setUnlocking(null)
    }
  }

  return (
    <div className="p-6 max-w-5xl">
      <div className="mb-6">
        <h1 className="font-display text-2xl font-bold text-blue-950">Student Requirements</h1>
        <p className="text-gray-500 mt-1">Browse and unlock contact details for ₹{UNLOCK_FEE}</p>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-4 mb-6 flex flex-col sm:flex-row gap-3">
        <Select value={subjectFilter} onValueChange={setSubjectFilter}>
          <SelectTrigger className="flex-1">
            <SelectValue placeholder="Filter by Subject" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">All Subjects</SelectItem>
            {SUBJECTS.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={areaFilter} onValueChange={setAreaFilter}>
          <SelectTrigger className="flex-1">
            <SelectValue placeholder="Filter by Area" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">All Areas</SelectItem>
            {MUMBAI_AREAS.map((a) => <SelectItem key={a} value={a}>{a}</SelectItem>)}
          </SelectContent>
        </Select>
        {(subjectFilter || areaFilter) && (
          <Button variant="outline" onClick={() => { setSubjectFilter(''); setAreaFilter('') }}>Clear</Button>
        )}
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-8 h-8 animate-spin text-orange-500" />
        </div>
      ) : requirements.length === 0 ? (
        <div className="text-center py-20 text-gray-400">
          <BookOpen className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p className="font-medium">No requirements found</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {requirements.map((req) => (
            <div key={req._id} className={`bg-white rounded-2xl border shadow-sm overflow-hidden transition-all ${req.isUnlocked ? 'border-green-200' : 'border-gray-100'}`}>
              {/* Header */}
              <div className={`px-5 py-3 flex items-center justify-between ${req.isUnlocked ? 'bg-green-50' : 'bg-gray-50'}`}>
                <div className="flex items-center gap-2">
                  <span className="badge-saffron">{req.subject}</span>
                  <span className="badge-navy">{req.class}</span>
                </div>
                {req.isUnlocked ? (
                  <span className="flex items-center gap-1 text-green-700 text-xs font-semibold">
                    <Unlock className="w-3.5 h-3.5" /> Unlocked
                  </span>
                ) : (
                  <span className="flex items-center gap-1 text-gray-400 text-xs">
                    <Lock className="w-3.5 h-3.5" /> Locked
                  </span>
                )}
              </div>

              <div className="p-5 space-y-3">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <MapPin className="w-4 h-4 text-blue-500 shrink-0" />
                  <span>{req.area}</span>
                  {req.teachingMode && <Badge variant="outline" className="text-xs ml-auto">{req.teachingMode}</Badge>}
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <IndianRupee className="w-4 h-4 text-green-500 shrink-0" />
                  <span>Budget: <strong>{formatCurrency(req.budget)}/month</strong></span>
                </div>
                {req.description && (
                  <p className="text-sm text-gray-500 leading-relaxed">{req.description}</p>
                )}

                {/* Unlocked contact */}
                {req.isUnlocked && req.contact ? (
                  <div className="bg-green-50 border border-green-100 rounded-xl p-4 space-y-2">
                    <div className="flex items-center gap-2 text-green-800 font-semibold text-sm">
                      <User className="w-4 h-4" /> {req.name}
                    </div>
                    <div className="flex items-center gap-2 text-green-700 text-sm">
                      <Phone className="w-4 h-4" /> {req.contact}
                    </div>
                  </div>
                ) : (
                  <div className="pt-2">
                    <Button
                      onClick={() => handleUnlock(req._id)}
                      disabled={unlocking === req._id}
                      className="w-full"
                      size="sm"
                    >
                      {unlocking === req._id ? (
                        <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Processing...</>
                      ) : (
                        <><Lock className="w-4 h-4 mr-2" /> Unlock for ₹{UNLOCK_FEE}</>
                      )}
                    </Button>
                  </div>
                )}

                <p className="text-xs text-gray-400">{formatDate(req.createdAt)}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
