import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { redirect } from 'next/navigation'
import Link from 'next/link'
import { LayoutDashboard, User, FileText, CreditCard, GraduationCap } from 'lucide-react'

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const session = await getServerSession(authOptions)
  const user = session?.user as any

  if (!session) redirect('/login')
  if (user?.role !== 'teacher') redirect('/')

  const navItems = [
    { href: '/dashboard', label: 'Overview', icon: LayoutDashboard },
    { href: '/dashboard/profile', label: 'My Profile', icon: User },
    { href: '/dashboard/requirements', label: 'Requirements', icon: FileText },
    { href: '/dashboard/payment', label: 'Payments', icon: CreditCard },
  ]

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <aside className="hidden md:flex flex-col w-64 bg-blue-950 text-white min-h-screen">
        <div className="p-5 border-b border-blue-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-orange-500 flex items-center justify-center">
              <GraduationCap className="w-4 h-4 text-white" />
            </div>
            <div>
              <div className="text-sm font-bold text-white">Teacher Portal</div>
              <div className="text-xs text-blue-300 truncate max-w-[140px]">{user?.name}</div>
            </div>
          </div>
        </div>
        <nav className="flex-1 p-4 space-y-1">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-blue-200 hover:bg-blue-800 hover:text-white transition-colors text-sm font-medium"
            >
              <item.icon className="w-4 h-4" />
              {item.label}
            </Link>
          ))}
        </nav>
        {!user?.isApproved && (
          <div className="m-4 p-3 bg-amber-500/20 border border-amber-400/30 rounded-lg">
            <p className="text-amber-300 text-xs">⏳ Account pending admin approval</p>
          </div>
        )}
      </aside>

      {/* Mobile top nav */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-blue-950 z-50 flex border-t border-blue-800">
        {navItems.map((item) => (
          <Link key={item.href} href={item.href} className="flex-1 flex flex-col items-center gap-1 py-2 text-blue-300 hover:text-white transition-colors">
            <item.icon className="w-5 h-5" />
            <span className="text-xs">{item.label}</span>
          </Link>
        ))}
      </div>

      {/* Main */}
      <main className="flex-1 overflow-auto pb-20 md:pb-0">
        {children}
      </main>
    </div>
  )
}
