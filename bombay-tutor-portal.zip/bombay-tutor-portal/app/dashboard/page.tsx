import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import Link from 'next/link'
import { FileText, User, CreditCard, ChevronRight, AlertCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default async function DashboardPage() {
  const session = await getServerSession(authOptions)
  const user = session?.user as any

  return (
    <div className="p-6 max-w-5xl">
      <div className="mb-8">
        <h1 className="font-display text-2xl font-bold text-blue-950">
          Welcome back, {user?.name?.split(' ')[0]}! 👋
        </h1>
        <p className="text-gray-500 mt-1">Here&apos;s your teacher dashboard overview.</p>
      </div>

      {!user?.isApproved && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-6 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-amber-800">Account Pending Approval</p>
            <p className="text-amber-600 text-sm mt-1">Your teacher account is under review. You&apos;ll be able to view and unlock student requirements once approved by the admin.</p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
        {[
          { label: 'Complete Profile', icon: User, href: '/dashboard/profile', desc: 'Add your subjects, areas & fees', color: 'bg-blue-50 text-blue-600' },
          { label: 'View Requirements', icon: FileText, href: '/dashboard/requirements', desc: 'Browse student requirements', color: 'bg-orange-50 text-orange-600' },
          { label: 'My Payments', icon: CreditCard, href: '/dashboard/payment', desc: 'View unlock history', color: 'bg-green-50 text-green-600' },
        ].map((item) => (
          <Link key={item.href} href={item.href} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 hover:shadow-md hover:-translate-y-0.5 transition-all group">
            <div className={`w-12 h-12 rounded-xl ${item.color} flex items-center justify-center mb-3`}>
              <item.icon className="w-6 h-6" />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-semibold text-blue-950">{item.label}</p>
                <p className="text-sm text-gray-500 mt-0.5">{item.desc}</p>
              </div>
              <ChevronRight className="w-4 h-4 text-gray-400 group-hover:text-orange-500 transition-colors" />
            </div>
          </Link>
        ))}
      </div>

      {/* Info Box */}
      <div className="bg-blue-950 rounded-2xl p-6 text-white">
        <h2 className="font-display text-lg font-bold mb-2">How Unlocking Works</h2>
        <div className="space-y-2 text-blue-200 text-sm">
          <p>1. Browse student requirements in the <strong className="text-white">Requirements</strong> tab.</p>
          <p>2. Find requirements that match your subjects and area.</p>
          <p>3. Pay ₹500 via Razorpay to unlock the student&apos;s contact details.</p>
          <p>4. Contact the student directly and start teaching!</p>
        </div>
        <Link href="/dashboard/requirements" className="mt-4 inline-block">
          <Button size="sm" className="bg-orange-500 hover:bg-orange-400 mt-2">
            Browse Requirements <ChevronRight className="w-4 h-4 ml-1" />
          </Button>
        </Link>
      </div>
    </div>
  )
}
