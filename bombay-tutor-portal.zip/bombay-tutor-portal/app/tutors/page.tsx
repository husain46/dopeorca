'use client'

import { useState, useEffect, useCallback } from 'react'
import { useSearchParams, useRouter } from 'next/navigation'
import Link from 'next/link'
import { Search, MapPin, BookOpen, Loader2, ChevronRight, Star, SlidersHorizontal } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { SUBJECTS, MUMBAI_AREAS, CLASSES, formatCurrency } from '@/lib/utils'

interface Tutor {
  _id: string
  name: string
  subjects: string[]
  classes: string[]
  areas: string[]
  experience: number
  fees: number
  teachingMode: string
  bio: string
  qualification: string
  gender?: string
}

export default function TutorsPage() {
  const searchParams = useSearchParams()
  const router = useRouter()

  const [tutors, setTutors] = useState<Tutor[]>([])
  const [loading, setLoading] = useState(true)
  const [total, setTotal] = useState(0)

  const [subject, setSubject] = useState(searchParams.get('subject') || '')
  const [area, setArea] = useState(searchParams.get('area') || '')
  const [classLevel, setClassLevel] = useState(searchParams.get('class') || '')

  const fetchTutors = useCallback(async () => {
    setLoading(true)
    const params = new URLSearchParams()
    if (subject) params.set('subject', subject)
    if (area) params.set('area', area)
    if (classLevel) params.set('class', classLevel)

    const res = await fetch(`/api/tutors?${params}`)
    const data = await res.json()
    setTutors(data.tutors || [])
    setTotal(data.total || 0)
    setLoading(false)
  }, [subject, area, classLevel])

  useEffect(() => { fetchTutors() }, [fetchTutors])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    fetchTutors()
  }

  const clearFilters = () => {
    setSubject('')
    setArea('')
    setClassLevel('')
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-blue-950 text-white py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="font-display text-3xl md:text-4xl font-bold mb-2">Find a Tutor</h1>
          <p className="text-blue-300">Verified tutors across Mumbai, Thane & Navi Mumbai</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search Filters */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-5 mb-8">
          <form onSubmit={handleSearch} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <Select value={subject} onValueChange={setSubject}>
              <SelectTrigger>
                <SelectValue placeholder="Select Subject" />
              </SelectTrigger>
              <SelectContent>
                {SUBJECTS.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={area} onValueChange={setArea}>
              <SelectTrigger>
                <SelectValue placeholder="Select Area" />
              </SelectTrigger>
              <SelectContent>
                {MUMBAI_AREAS.map((a) => <SelectItem key={a} value={a}>{a}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={classLevel} onValueChange={setClassLevel}>
              <SelectTrigger>
                <SelectValue placeholder="Select Class" />
              </SelectTrigger>
              <SelectContent>
                {CLASSES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
              </SelectContent>
            </Select>
            <div className="flex gap-2">
              <Button type="submit" className="flex-1">
                <Search className="w-4 h-4 mr-2" /> Search
              </Button>
              {(subject || area || classLevel) && (
                <Button type="button" variant="outline" onClick={clearFilters} className="px-3">✕</Button>
              )}
            </div>
          </form>
        </div>

        {/* Results count */}
        <div className="flex items-center justify-between mb-5">
          <p className="text-gray-600 text-sm">
            {loading ? 'Searching...' : `${total} tutor${total !== 1 ? 's' : ''} found`}
          </p>
          {(subject || area || classLevel) && (
            <div className="flex gap-2 flex-wrap">
              {subject && <Badge variant="default">{subject} ✕</Badge>}
              {area && <Badge variant="secondary">{area} ✕</Badge>}
              {classLevel && <Badge className="bg-green-100 text-green-700">{classLevel} ✕</Badge>}
            </div>
          )}
        </div>

        {/* Tutor Cards */}
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-orange-500" />
          </div>
        ) : tutors.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="font-display text-xl font-semibold text-gray-700 mb-2">No tutors found</h3>
            <p className="text-gray-500 mb-4">Try adjusting your filters or check back later</p>
            <Button variant="outline" onClick={clearFilters}>Clear Filters</Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {tutors.map((tutor) => (
              <div key={tutor._id} className="bg-white rounded-2xl border border-gray-100 shadow-sm card-hover overflow-hidden">
                {/* Card top */}
                <div className="bg-gradient-to-br from-blue-50 to-orange-50 p-5 pb-4">
                  <div className="flex items-start gap-4">
                    <div className="w-14 h-14 rounded-xl bg-blue-900 text-white flex items-center justify-center font-display font-bold text-xl shrink-0">
                      {tutor.name.charAt(0)}
                    </div>
                    <div className="min-w-0">
                      <h3 className="font-display font-semibold text-blue-950 text-lg leading-tight truncate">{tutor.name}</h3>
                      {tutor.qualification && (
                        <p className="text-gray-500 text-xs mt-0.5 truncate">{tutor.qualification}</p>
                      )}
                      <div className="flex items-center gap-1.5 mt-1.5">
                        <Badge variant={tutor.teachingMode === 'Online' ? 'secondary' : tutor.teachingMode === 'Both' ? 'success' : 'default'}>
                          {tutor.teachingMode}
                        </Badge>
                        {tutor.experience > 0 && (
                          <span className="text-xs text-gray-500">{tutor.experience}y exp</span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-5 pt-4 space-y-3">
                  {/* Subjects */}
                  <div>
                    <div className="flex items-center gap-1.5 mb-1.5">
                      <BookOpen className="w-3.5 h-3.5 text-orange-500" />
                      <span className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Subjects</span>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {tutor.subjects.slice(0, 4).map((s) => (
                        <span key={s} className="badge-saffron">{s}</span>
                      ))}
                      {tutor.subjects.length > 4 && (
                        <span className="text-xs text-gray-400">+{tutor.subjects.length - 4} more</span>
                      )}
                    </div>
                  </div>

                  {/* Areas */}
                  <div>
                    <div className="flex items-center gap-1.5 mb-1.5">
                      <MapPin className="w-3.5 h-3.5 text-blue-500" />
                      <span className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Areas</span>
                    </div>
                    <p className="text-sm text-gray-600 leading-relaxed">{tutor.areas.slice(0, 3).join(', ')}{tutor.areas.length > 3 && `, +${tutor.areas.length - 3}`}</p>
                  </div>

                  {/* Fees & CTA */}
                  <div className="flex items-center justify-between pt-2 border-t border-gray-50">
                    <div>
                      <span className="text-xs text-gray-400">Hourly Fee</span>
                      <p className="font-display font-bold text-blue-950 text-lg">{formatCurrency(tutor.fees)}/hr</p>
                    </div>
                    <Link href={`/tutor/${tutor._id}`}>
                      <Button size="sm" className="gap-1.5">
                        View Profile <ChevronRight className="w-3.5 h-3.5" />
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
