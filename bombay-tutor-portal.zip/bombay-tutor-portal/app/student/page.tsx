import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import Link from 'next/link'
import { PlusCircle, Search, FileText, ChevronRight } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default async function StudentDashboardPage() {
  const session = await getServerSession(authOptions)
  const user = session?.user as any

  return (
    <div className="p-6 max-w-4xl">
      <div className="mb-8">
        <h1 className="font-display text-2xl font-bold text-blue-950">
          Hello, {user?.name?.split(' ')[0]}! 👋
        </h1>
        <p className="text-gray-500 mt-1">Find the perfect tutor for your needs.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
        {[
          { label: 'Post Requirement', icon: PlusCircle, href: '/student/post', desc: 'Let tutors find you for free', color: 'bg-orange-50 text-orange-600' },
          { label: 'Browse Tutors', icon: Search, href: '/tutors', desc: 'Search & contact tutors directly', color: 'bg-blue-50 text-blue-600' },
          { label: 'My Requirements', icon: FileText, href: '/student/requirements', desc: 'View your posted requirements', color: 'bg-green-50 text-green-600' },
        ].map((item) => (
          <Link key={item.href} href={item.href} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 hover:shadow-md hover:-translate-y-0.5 transition-all group">
            <div className={`w-12 h-12 rounded-xl ${item.color} flex items-center justify-center mb-3`}>
              <item.icon className="w-6 h-6" />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-semibold text-blue-950">{item.label}</p>
                <p className="text-sm text-gray-500 mt-0.5">{item.desc}</p>
              </div>
              <ChevronRight className="w-4 h-4 text-gray-400 group-hover:text-orange-500 transition-colors" />
            </div>
          </Link>
        ))}
      </div>

      <div className="bg-blue-950 rounded-2xl p-6 text-white">
        <h2 className="font-display text-lg font-bold mb-2">How It Works for You</h2>
        <div className="space-y-2 text-blue-200 text-sm">
          <p>1. <strong className="text-white">Post your requirement</strong> — subject, class, area, and budget.</p>
          <p>2. Tutors will browse your requirement and unlock your contact.</p>
          <p>3. <strong className="text-white">You&apos;ll be contacted directly</strong> by interested tutors.</p>
          <p>4. Or you can browse tutors and contact them directly yourself — it&apos;s free!</p>
        </div>
        <Link href="/student/post" className="mt-4 inline-block">
          <Button size="sm" className="bg-orange-500 hover:bg-orange-400 mt-2">
            Post Requirement <ChevronRight className="w-4 h-4 ml-1" />
          </Button>
        </Link>
      </div>
    </div>
  )
}
