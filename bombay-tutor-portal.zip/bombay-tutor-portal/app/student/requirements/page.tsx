'use client'

import { useState, useEffect } from 'react'
import { Loader2, PlusCircle, MapPin, BookOpen, IndianRupee, Calendar } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { formatCurrency, formatDate } from '@/lib/utils'
import Link from 'next/link'

interface Requirement {
  _id: string
  subject: string
  class: string
  area: string
  budget: number
  contact: string
  name: string
  description?: string
  teachingMode?: string
  isActive: boolean
  createdAt: string
}

export default function StudentRequirementsPage() {
  const [requirements, setRequirements] = useState<Requirement[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/requirements')
      .then((r) => r.json())
      .then((data) => { setRequirements(data.requirements || []); setLoading(false) })
      .catch(() => setLoading(false))
  }, [])

  return (
    <div className="p-6 max-w-4xl">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-2xl font-bold text-blue-950">My Requirements</h1>
          <p className="text-gray-500 mt-1">{requirements.length} requirement{requirements.length !== 1 ? 's' : ''} posted</p>
        </div>
        <Link href="/student/post">
          <Button size="sm">
            <PlusCircle className="w-4 h-4 mr-2" /> New Post
          </Button>
        </Link>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-8 h-8 animate-spin text-orange-500" />
        </div>
      ) : requirements.length === 0 ? (
        <div className="text-center py-20 bg-white rounded-2xl border border-gray-100">
          <BookOpen className="w-12 h-12 mx-auto mb-3 text-gray-300" />
          <h3 className="font-semibold text-gray-600 mb-2">No requirements posted yet</h3>
          <p className="text-gray-400 text-sm mb-5">Post your first requirement and let tutors find you.</p>
          <Link href="/student/post">
            <Button><PlusCircle className="w-4 h-4 mr-2" /> Post Requirement</Button>
          </Link>
        </div>
      ) : (
        <div className="space-y-4">
          {requirements.map((req) => (
            <div key={req._id} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
              <div className="flex items-start justify-between flex-wrap gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="badge-saffron">{req.subject}</span>
                    <span className="badge-navy">{req.class}</span>
                    {req.teachingMode && <Badge variant="outline">{req.teachingMode}</Badge>}
                    <Badge variant={req.isActive ? 'success' : 'secondary'}>{req.isActive ? 'Active' : 'Inactive'}</Badge>
                  </div>
                  <p className="font-semibold text-blue-950 mt-2">{req.name}</p>
                </div>
                <div className="text-right">
                  <p className="font-display font-bold text-blue-950">{formatCurrency(req.budget)}/mo</p>
                </div>
              </div>

              <div className="mt-3 grid grid-cols-2 gap-2 text-sm text-gray-600">
                <div className="flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-blue-400" /> {req.area}
                </div>
                <div className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-gray-400" /> {formatDate(req.createdAt)}
                </div>
              </div>
              {req.description && (
                <p className="mt-2 text-sm text-gray-500 leading-relaxed">{req.description}</p>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
