'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Loader2, CheckCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { SUBJECTS, MUMBAI_AREAS, CLASSES, TEACHING_MODES } from '@/lib/utils'
import Link from 'next/link'

export default function StudentPostPage() {
  const router = useRouter()
  const [form, setForm] = useState({
    name: '', subject: '', classLevel: '', area: '',
    budget: '', contact: '', description: '', teachingMode: '',
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    const res = await fetch('/api/requirements', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    })
    const data = await res.json()
    setLoading(false)
    if (!res.ok) { setError(data.error || 'Failed'); return }
    setSuccess(true)
  }

  if (success) return (
    <div className="p-6 flex items-start justify-center min-h-[60vh]">
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-10 max-w-md w-full text-center mt-10">
        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <CheckCircle className="w-9 h-9 text-green-600" />
        </div>
        <h2 className="font-display text-2xl font-bold text-blue-950 mb-2">Posted!</h2>
        <p className="text-gray-500 mb-6">Your requirement is live. Tutors will contact you soon.</p>
        <div className="flex gap-3">
          <Button variant="outline" className="flex-1" onClick={() => setSuccess(false)}>Post Another</Button>
          <Link href="/student/requirements" className="flex-1">
            <Button className="w-full">View All Posts</Button>
          </Link>
        </div>
      </div>
    </div>
  )

  return (
    <div className="p-6 max-w-2xl">
      <div className="mb-6">
        <h1 className="font-display text-2xl font-bold text-blue-950">Post a Requirement</h1>
        <p className="text-gray-500 mt-1">Free for students. Tutors will reach out to you.</p>
      </div>

      {error && <div className="bg-red-50 border border-red-200 text-red-700 rounded-lg px-4 py-3 text-sm mb-5">{error}</div>}

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div className="space-y-1.5">
              <Label>Your Name *</Label>
              <Input placeholder="Parent / Student name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
            </div>
            <div className="space-y-1.5">
              <Label>Contact Number *</Label>
              <Input placeholder="+91 98765 43210" value={form.contact} onChange={(e) => setForm({ ...form, contact: e.target.value })} required />
            </div>
            <div className="space-y-1.5">
              <Label>Subject *</Label>
              <Select value={form.subject} onValueChange={(v) => setForm({ ...form, subject: v })}>
                <SelectTrigger><SelectValue placeholder="Select subject" /></SelectTrigger>
                <SelectContent>{SUBJECTS.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Class / Level *</Label>
              <Select value={form.classLevel} onValueChange={(v) => setForm({ ...form, classLevel: v })}>
                <SelectTrigger><SelectValue placeholder="Select class" /></SelectTrigger>
                <SelectContent>{CLASSES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Area *</Label>
              <Select value={form.area} onValueChange={(v) => setForm({ ...form, area: v })}>
                <SelectTrigger><SelectValue placeholder="Your area" /></SelectTrigger>
                <SelectContent>{MUMBAI_AREAS.map((a) => <SelectItem key={a} value={a}>{a}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Monthly Budget (₹) *</Label>
              <Input type="number" placeholder="e.g. 3000" value={form.budget} onChange={(e) => setForm({ ...form, budget: e.target.value })} required min={0} />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>Teaching Mode</Label>
            <Select value={form.teachingMode} onValueChange={(v) => setForm({ ...form, teachingMode: v })}>
              <SelectTrigger><SelectValue placeholder="Home visit / Online / Both" /></SelectTrigger>
              <SelectContent>{TEACHING_MODES.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Additional Details</Label>
            <Textarea placeholder="Any special notes for tutors..." value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={3} />
          </div>
          <Button type="submit" size="lg" className="w-full" disabled={loading}>
            {loading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Posting...</> : 'Post Requirement Free'}
          </Button>
        </form>
      </div>
    </div>
  )
}
