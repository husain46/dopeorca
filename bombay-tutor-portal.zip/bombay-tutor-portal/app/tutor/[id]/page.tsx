import { notFound } from 'next/navigation'
import Link from 'next/link'
import { MapPin, BookOpen, Clock, GraduationCap, DollarSign, ArrowLeft, Monitor, Home, Layers } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { formatCurrency } from '@/lib/utils'

async function getTutor(id: string) {
  try {
    const res = await fetch(`${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/api/tutors/${id}`, {
      cache: 'no-store',
    })
    if (!res.ok) return null
    return res.json()
  } catch {
    return null
  }
}

export default async function TutorProfilePage({ params }: { params: { id: string } }) {
  const tutor = await getTutor(params.id)
  if (!tutor) notFound()

  const modeIcon = tutor.teachingMode === 'Online' ? Monitor : tutor.teachingMode === 'Home Visit' ? Home : Layers

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Back bar */}
      <div className="bg-white border-b border-gray-100">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <Link href="/tutors" className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-orange-600 transition-colors">
            <ArrowLeft className="w-4 h-4" /> Back to Tutors
          </Link>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-5">
            {/* Profile card */}
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
              <div className="bg-gradient-to-br from-blue-900 to-blue-700 p-6 text-white text-center">
                <div className="w-20 h-20 rounded-2xl bg-white/20 backdrop-blur flex items-center justify-center font-display font-bold text-3xl mx-auto mb-3">
                  {tutor.name.charAt(0)}
                </div>
                <h1 className="font-display text-xl font-bold">{tutor.name}</h1>
                {tutor.qualification && (
                  <p className="text-blue-200 text-sm mt-1">{tutor.qualification}</p>
                )}
                <Badge className="mt-3 bg-white/20 text-white border-white/30">
                  {tutor.teachingMode}
                </Badge>
              </div>
              <div className="p-5 space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-orange-50 flex items-center justify-center">
                    <DollarSign className="w-4 h-4 text-orange-500" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-400">Hourly Fee</p>
                    <p className="font-display font-bold text-blue-950">{formatCurrency(tutor.fees)}/hr</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-blue-50 flex items-center justify-center">
                    <Clock className="w-4 h-4 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-400">Experience</p>
                    <p className="font-semibold text-blue-950">{tutor.experience} years</p>
                  </div>
                </div>
                {tutor.gender && (
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-purple-50 flex items-center justify-center">
                      <GraduationCap className="w-4 h-4 text-purple-600" />
                    </div>
                    <div>
                      <p className="text-xs text-gray-400">Gender</p>
                      <p className="font-semibold text-blue-950">{tutor.gender}</p>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Post requirement CTA */}
            <div className="bg-orange-50 rounded-2xl border border-orange-100 p-5 text-center">
              <h3 className="font-display font-semibold text-orange-800 mb-2">Need a Tutor?</h3>
              <p className="text-orange-600 text-sm mb-4">Post your requirement and get contacted by tutors for free.</p>
              <Link href="/post-requirement">
                <Button className="w-full" size="sm">Post Requirement Free</Button>
              </Link>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2 space-y-5">
            {/* Bio */}
            {tutor.bio && (
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
                <h2 className="font-display text-lg font-semibold text-blue-950 mb-3">About</h2>
                <p className="text-gray-600 leading-relaxed">{tutor.bio}</p>
              </div>
            )}

            {/* Subjects */}
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
              <div className="flex items-center gap-2 mb-4">
                <BookOpen className="w-5 h-5 text-orange-500" />
                <h2 className="font-display text-lg font-semibold text-blue-950">Subjects</h2>
              </div>
              <div className="flex flex-wrap gap-2">
                {tutor.subjects.map((s: string) => (
                  <span key={s} className="badge-saffron text-sm">{s}</span>
                ))}
              </div>
            </div>

            {/* Classes */}
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
              <div className="flex items-center gap-2 mb-4">
                <GraduationCap className="w-5 h-5 text-blue-600" />
                <h2 className="font-display text-lg font-semibold text-blue-950">Classes</h2>
              </div>
              <div className="flex flex-wrap gap-2">
                {tutor.classes.map((c: string) => (
                  <span key={c} className="badge-navy text-sm">{c}</span>
                ))}
              </div>
            </div>

            {/* Areas */}
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
              <div className="flex items-center gap-2 mb-4">
                <MapPin className="w-5 h-5 text-green-600" />
                <h2 className="font-display text-lg font-semibold text-blue-950">Teaching Areas</h2>
              </div>
              <div className="flex flex-wrap gap-2">
                {tutor.areas.map((a: string) => (
                  <span key={a} className="inline-flex items-center gap-1 bg-green-50 text-green-700 border border-green-100 text-sm font-medium px-3 py-1 rounded-full">
                    <MapPin className="w-3 h-3" />{a}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
