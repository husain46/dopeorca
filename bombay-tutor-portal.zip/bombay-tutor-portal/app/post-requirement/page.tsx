'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useSession } from 'next-auth/react'
import Link from 'next/link'
import { Loader2, CheckCircle, FileText } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { SUBJECTS, MUMBAI_AREAS, CLASSES, TEACHING_MODES } from '@/lib/utils'

export default function PostRequirementPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const user = session?.user as any

  const [form, setForm] = useState({
    name: '', subject: '', classLevel: '', area: '', budget: '',
    contact: '', description: '', teachingMode: '',
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!session) { router.push('/login'); return }
    if (user?.role !== 'student') {
      setError('Only students/parents can post requirements.')
      return
    }
    setLoading(true)
    setError('')

    const res = await fetch('/api/requirements', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    })
    const data = await res.json()
    setLoading(false)

    if (!res.ok) { setError(data.error || 'Failed to post'); return }
    setSuccess(true)
  }

  if (success) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-lg p-10 max-w-md w-full text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-9 h-9 text-green-600" />
          </div>
          <h2 className="font-display text-2xl font-bold text-blue-950 mb-2">Requirement Posted!</h2>
          <p className="text-gray-500 mb-6">Tutors in your area will see your requirement and reach out to you directly.</p>
          <div className="flex gap-3">
            <Link href="/tutors" className="flex-1">
              <Button variant="outline" className="w-full">Browse Tutors</Button>
            </Link>
            <Link href="/student/requirements" className="flex-1">
              <Button className="w-full">View My Posts</Button>
            </Link>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-blue-950 text-white py-10">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3 mb-2">
            <FileText className="w-6 h-6 text-orange-400" />
            <h1 className="font-display text-3xl font-bold">Post a Tutor Requirement</h1>
          </div>
          <p className="text-blue-300">Free for students. Tutors will contact you directly.</p>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {status === 'unauthenticated' && (
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-6 text-amber-800 text-sm">
            <strong>Please log in</strong> to post a requirement.{' '}
            <Link href="/login" className="underline font-semibold">Login here</Link> or{' '}
            <Link href="/register" className="underline font-semibold">Register free</Link>.
          </div>
        )}

        {user?.role === 'teacher' && (
          <div className="bg-red-50 border border-red-200 rounded-xl p-4 mb-6 text-red-700 text-sm">
            Only student/parent accounts can post requirements. Please create a student account.
          </div>
        )}

        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 md:p-8">
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 rounded-lg px-4 py-3 text-sm mb-5">{error}</div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div className="space-y-1.5">
                <Label>Your Name *</Label>
                <Input placeholder="Parent / Student name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
              </div>
              <div className="space-y-1.5">
                <Label>Contact Number *</Label>
                <Input placeholder="+91 98765 43210" value={form.contact} onChange={(e) => setForm({ ...form, contact: e.target.value })} required />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div className="space-y-1.5">
                <Label>Subject Required *</Label>
                <Select value={form.subject} onValueChange={(v) => setForm({ ...form, subject: v })}>
                  <SelectTrigger><SelectValue placeholder="Select subject" /></SelectTrigger>
                  <SelectContent>{SUBJECTS.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Class / Level *</Label>
                <Select value={form.classLevel} onValueChange={(v) => setForm({ ...form, classLevel: v })}>
                  <SelectTrigger><SelectValue placeholder="Select class" /></SelectTrigger>
                  <SelectContent>{CLASSES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div className="space-y-1.5">
                <Label>Area / Location *</Label>
                <Select value={form.area} onValueChange={(v) => setForm({ ...form, area: v })}>
                  <SelectTrigger><SelectValue placeholder="Your area" /></SelectTrigger>
                  <SelectContent>{MUMBAI_AREAS.map((a) => <SelectItem key={a} value={a}>{a}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Monthly Budget (₹) *</Label>
                <Input type="number" placeholder="e.g. 3000" value={form.budget} onChange={(e) => setForm({ ...form, budget: e.target.value })} required min={0} />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label>Teaching Mode Preference</Label>
              <Select value={form.teachingMode} onValueChange={(v) => setForm({ ...form, teachingMode: v })}>
                <SelectTrigger><SelectValue placeholder="Home visit / Online / Both" /></SelectTrigger>
                <SelectContent>{TEACHING_MODES.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <Label>Additional Details</Label>
              <Textarea
                placeholder="Describe any special requirements, availability, or other details..."
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                rows={4}
              />
            </div>

            <Button
              type="submit"
              size="lg"
              className="w-full"
              disabled={loading || status === 'unauthenticated' || user?.role === 'teacher'}
            >
              {loading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Posting...</> : 'Post Requirement Free'}
            </Button>
          </form>
        </div>
      </div>
    </div>
  )
}
