import type { Metadata } from 'next'
import './globals.css'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import SessionProvider from '@/components/layout/SessionProvider'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import { Toaster } from '@/components/ui/toaster'

export const metadata: Metadata = {
  title: 'Bombay Home Tutors | Find Best Tutors in Mumbai',
  description:
    'Connect with qualified home tutors across Mumbai, Thane, Navi Mumbai and nearby areas. Post requirements or find students easily.',
  keywords: 'home tutors Mumbai, private tutors Mumbai, tuition Mumbai, online tutors',
}

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const session = await getServerSession(authOptions)

  return (
    <html lang="en">
      <body>
        <SessionProvider session={session}>
          <Navbar />
          <main className="min-h-screen">{children}</main>
          <Footer />
          <Toaster />
        </SessionProvider>
      </body>
    </html>
  )
}
