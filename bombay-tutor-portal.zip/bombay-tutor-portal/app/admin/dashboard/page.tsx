'use client'

import { useState, useEffect, useCallback } from 'react'
import { Users, FileText, CreditCard, TrendingUp, CheckCircle, XCircle, Trash2, Loader2, RefreshCw } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { formatCurrency, formatDate } from '@/lib/utils'
import { toast } from '@/components/ui/use-toast'
import { useSearchParams } from 'next/navigation'

type Tab = 'overview' | 'teachers' | 'students' | 'requirements' | 'payments'

export default function AdminDashboardPage() {
  const searchParams = useSearchParams()
  const tabParam = searchParams.get('tab') as Tab | null
  const [activeTab, setActiveTab] = useState<Tab>(tabParam || 'overview')

  const [stats, setStats] = useState<any>(null)
  const [teachers, setTeachers] = useState<any[]>([])
  const [students, setStudents] = useState<any[]>([])
  const [requirements, setRequirements] = useState<any[]>([])
  const [payments, setPayments] = useState<any[]>([])
  const [loading, setLoading] = useState(false)

  const fetchStats = useCallback(async () => {
    const res = await fetch('/api/admin/stats')
    const data = await res.json()
    setStats(data)
  }, [])

  const fetchTeachers = useCallback(async () => {
    setLoading(true)
    const res = await fetch('/api/admin/users?role=teacher')
    const data = await res.json()
    setTeachers(data.users || [])
    setLoading(false)
  }, [])

  const fetchStudents = useCallback(async () => {
    setLoading(true)
    const res = await fetch('/api/admin/users?role=student')
    const data = await res.json()
    setStudents(data.users || [])
    setLoading(false)
  }, [])

  const fetchRequirements = useCallback(async () => {
    setLoading(true)
    const res = await fetch('/api/admin/requirements')
    const data = await res.json()
    setRequirements(data.requirements || [])
    setLoading(false)
  }, [])

  const fetchPayments = useCallback(async () => {
    setLoading(true)
    const res = await fetch('/api/payments')
    const data = await res.json()
    setPayments(data.payments || [])
    setLoading(false)
  }, [])

  useEffect(() => {
    fetchStats()
    if (activeTab === 'teachers' || activeTab === 'overview') fetchTeachers()
    if (activeTab === 'students') fetchStudents()
    if (activeTab === 'requirements') fetchRequirements()
    if (activeTab === 'payments') fetchPayments()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab])

  const handleApprove = async (userId: string, approve: boolean) => {
    const res = await fetch(`/api/admin/users/${userId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ isApproved: approve }),
    })
    if (res.ok) {
      toast({ title: approve ? '✓ Teacher Approved' : '✗ Teacher Suspended', variant: approve ? 'success' as any : 'destructive' })
      fetchTeachers()
      fetchStats()
    }
  }

  const handleDelete = async (userId: string) => {
    if (!confirm('Are you sure you want to delete this user?')) return
    const res = await fetch(`/api/admin/users/${userId}`, { method: 'DELETE' })
    if (res.ok) {
      toast({ title: 'User deleted', variant: 'destructive' })
      fetchTeachers(); fetchStudents(); fetchStats()
    }
  }

  const tabs: { id: Tab; label: string; icon: any }[] = [
    { id: 'overview', label: 'Overview', icon: TrendingUp },
    { id: 'teachers', label: 'Teachers', icon: Users },
    { id: 'students', label: 'Students', icon: Users },
    { id: 'requirements', label: 'Requirements', icon: FileText },
    { id: 'payments', label: 'Payments', icon: CreditCard },
  ]

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="font-display text-2xl font-bold text-slate-900">Admin Dashboard</h1>
        <p className="text-slate-500 text-sm mt-1">Manage users, requirements, and payments</p>
      </div>

      {/* Tab bar */}
      <div className="flex gap-1 bg-gray-100 p-1 rounded-xl mb-6 overflow-x-auto">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${
              activeTab === tab.id ? 'bg-white shadow text-slate-900' : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Overview */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
            {stats && [
              { label: 'Total Teachers', value: stats.teachers, color: 'text-blue-600' },
              { label: 'Total Students', value: stats.students, color: 'text-orange-600' },
              { label: 'Pending Approvals', value: stats.pendingTeachers, color: 'text-amber-600' },
              { label: 'Active Requirements', value: stats.requirements, color: 'text-green-600' },
              { label: 'Paid Unlocks', value: stats.payments, color: 'text-purple-600' },
              { label: 'Total Revenue', value: formatCurrency(stats.totalRevenue), color: 'text-emerald-600' },
            ].map((stat) => (
              <div key={stat.label} className="bg-white rounded-xl border border-gray-100 shadow-sm p-5 text-center">
                <p className={`font-display text-3xl font-bold ${stat.color}`}>{stat.value}</p>
                <p className="text-gray-500 text-sm mt-1">{stat.label}</p>
              </div>
            ))}
          </div>

          {/* Pending Teachers */}
          {teachers.filter((t) => !t.isApproved).length > 0 && (
            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5">
              <h3 className="font-semibold text-amber-800 mb-3">⏳ Pending Teacher Approvals ({teachers.filter((t) => !t.isApproved).length})</h3>
              <div className="space-y-3">
                {teachers.filter((t) => !t.isApproved).map((teacher) => (
                  <div key={teacher._id} className="bg-white rounded-xl p-4 flex items-center justify-between gap-4">
                    <div>
                      <p className="font-semibold text-slate-800">{teacher.name}</p>
                      <p className="text-slate-500 text-sm">{teacher.email}</p>
                      <p className="text-xs text-slate-400">{formatDate(teacher.createdAt)}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" variant="success" onClick={() => handleApprove(teacher._id, true)}>
                        <CheckCircle className="w-4 h-4 mr-1" /> Approve
                      </Button>
                      <Button size="sm" variant="destructive" onClick={() => handleDelete(teacher._id)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Teachers */}
      {activeTab === 'teachers' && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <p className="text-sm text-slate-500">{teachers.length} teachers registered</p>
            <Button size="sm" variant="outline" onClick={fetchTeachers}>
              <RefreshCw className="w-4 h-4 mr-1" /> Refresh
            </Button>
          </div>
          {loading ? <div className="flex justify-center py-10"><Loader2 className="animate-spin text-orange-500 w-8 h-8" /></div> : (
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b text-xs text-gray-500 uppercase tracking-wide">
                    <tr>
                      <th className="text-left px-5 py-3">Name</th>
                      <th className="text-left px-5 py-3">Email</th>
                      <th className="text-left px-5 py-3">Status</th>
                      <th className="text-left px-5 py-3">Joined</th>
                      <th className="text-left px-5 py-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {teachers.map((t) => (
                      <tr key={t._id} className="hover:bg-gray-50">
                        <td className="px-5 py-4 font-medium text-slate-800">{t.name}</td>
                        <td className="px-5 py-4 text-sm text-slate-500">{t.email}</td>
                        <td className="px-5 py-4">
                          <Badge variant={t.isApproved ? 'success' : 'warning'}>{t.isApproved ? 'Approved' : 'Pending'}</Badge>
                        </td>
                        <td className="px-5 py-4 text-sm text-slate-400">{formatDate(t.createdAt)}</td>
                        <td className="px-5 py-4">
                          <div className="flex gap-2">
                            {!t.isApproved ? (
                              <Button size="sm" variant="success" onClick={() => handleApprove(t._id, true)}>
                                <CheckCircle className="w-3.5 h-3.5 mr-1" /> Approve
                              </Button>
                            ) : (
                              <Button size="sm" variant="outline" onClick={() => handleApprove(t._id, false)}>
                                <XCircle className="w-3.5 h-3.5 mr-1" /> Suspend
                              </Button>
                            )}
                            <Button size="sm" variant="destructive" onClick={() => handleDelete(t._id)}>
                              <Trash2 className="w-3.5 h-3.5" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Students */}
      {activeTab === 'students' && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <p className="text-sm text-slate-500">{students.length} students registered</p>
            <Button size="sm" variant="outline" onClick={fetchStudents}><RefreshCw className="w-4 h-4 mr-1" /> Refresh</Button>
          </div>
          {loading ? <div className="flex justify-center py-10"><Loader2 className="animate-spin text-orange-500 w-8 h-8" /></div> : (
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b text-xs text-gray-500 uppercase tracking-wide">
                    <tr>
                      <th className="text-left px-5 py-3">Name</th>
                      <th className="text-left px-5 py-3">Email</th>
                      <th className="text-left px-5 py-3">Joined</th>
                      <th className="text-left px-5 py-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {students.map((s) => (
                      <tr key={s._id} className="hover:bg-gray-50">
                        <td className="px-5 py-4 font-medium text-slate-800">{s.name}</td>
                        <td className="px-5 py-4 text-sm text-slate-500">{s.email}</td>
                        <td className="px-5 py-4 text-sm text-slate-400">{formatDate(s.createdAt)}</td>
                        <td className="px-5 py-4">
                          <Button size="sm" variant="destructive" onClick={() => handleDelete(s._id)}>
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Requirements */}
      {activeTab === 'requirements' && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <p className="text-sm text-slate-500">{requirements.length} total requirements</p>
            <Button size="sm" variant="outline" onClick={fetchRequirements}><RefreshCw className="w-4 h-4 mr-1" /> Refresh</Button>
          </div>
          {loading ? <div className="flex justify-center py-10"><Loader2 className="animate-spin text-orange-500 w-8 h-8" /></div> : (
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b text-xs text-gray-500 uppercase tracking-wide">
                    <tr>
                      <th className="text-left px-5 py-3">Posted By</th>
                      <th className="text-left px-5 py-3">Subject</th>
                      <th className="text-left px-5 py-3">Class</th>
                      <th className="text-left px-5 py-3">Area</th>
                      <th className="text-left px-5 py-3">Budget</th>
                      <th className="text-left px-5 py-3">Contact</th>
                      <th className="text-left px-5 py-3">Date</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {requirements.map((r) => (
                      <tr key={r._id} className="hover:bg-gray-50">
                        <td className="px-5 py-4 text-sm text-slate-700">{(r.userId as any)?.name || '—'}</td>
                        <td className="px-5 py-4"><span className="badge-saffron">{r.subject}</span></td>
                        <td className="px-5 py-4 text-sm text-slate-600">{r.class}</td>
                        <td className="px-5 py-4 text-sm text-slate-600">{r.area}</td>
                        <td className="px-5 py-4 text-sm font-semibold text-slate-800">{formatCurrency(r.budget)}/mo</td>
                        <td className="px-5 py-4 text-sm text-slate-500">{r.contact}</td>
                        <td className="px-5 py-4 text-sm text-slate-400">{formatDate(r.createdAt)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Payments */}
      {activeTab === 'payments' && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <p className="text-sm text-slate-500">
              {payments.filter((p) => p.status === 'paid').length} successful payments · {' '}
              {formatCurrency(payments.filter((p) => p.status === 'paid').reduce((sum, p) => sum + p.amount, 0))} total
            </p>
            <Button size="sm" variant="outline" onClick={fetchPayments}><RefreshCw className="w-4 h-4 mr-1" /> Refresh</Button>
          </div>
          {loading ? <div className="flex justify-center py-10"><Loader2 className="animate-spin text-orange-500 w-8 h-8" /></div> : (
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b text-xs text-gray-500 uppercase tracking-wide">
                    <tr>
                      <th className="text-left px-5 py-3">Teacher</th>
                      <th className="text-left px-5 py-3">Requirement</th>
                      <th className="text-left px-5 py-3">Amount</th>
                      <th className="text-left px-5 py-3">Status</th>
                      <th className="text-left px-5 py-3">Payment ID</th>
                      <th className="text-left px-5 py-3">Date</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {payments.map((p) => (
                      <tr key={p._id} className="hover:bg-gray-50">
                        <td className="px-5 py-4 text-sm text-slate-700">{(p.userId as any)?.name || '—'}</td>
                        <td className="px-5 py-4 text-sm text-slate-600">
                          {(p.requirementId as any)?.subject} · {(p.requirementId as any)?.area || '—'}
                        </td>
                        <td className="px-5 py-4 font-semibold text-slate-800">{formatCurrency(p.amount)}</td>
                        <td className="px-5 py-4">
                          <Badge variant={p.status === 'paid' ? 'success' : p.status === 'failed' ? 'destructive' : 'warning'}>
                            {p.status}
                          </Badge>
                        </td>
                        <td className="px-5 py-4 text-xs text-slate-400 font-mono truncate max-w-[140px]">{p.razorpayPaymentId || p.razorpayOrderId}</td>
                        <td className="px-5 py-4 text-sm text-slate-400">{formatDate(p.createdAt)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
