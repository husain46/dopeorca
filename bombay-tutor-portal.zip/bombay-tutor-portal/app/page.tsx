import Link from 'next/link'
import { Search, MapPin, BookOpen, Star, Users, Shield, ChevronRight, GraduationCap } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { SUBJECTS, MUMBAI_AREAS } from '@/lib/utils'

export default function HomePage() {
  const featuredSubjects = SUBJECTS.slice(0, 8)
  const featuredAreas = MUMBAI_AREAS.slice(0, 12)

  return (
    <div className="flex flex-col">
      {/* Hero */}
      <section className="relative hero-gradient text-white overflow-hidden">
        <div className="absolute inset-0 section-pattern opacity-20" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-28">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur border border-white/20 text-white text-sm font-medium px-4 py-2 rounded-full mb-6">
              <MapPin className="w-4 h-4 text-orange-300" />
              Mumbai&apos;s Most Trusted Tutor Platform
            </div>
            <h1 className="font-display text-4xl md:text-6xl font-bold leading-tight mb-6">
              Find the Perfect{' '}
              <span className="text-orange-300">Home Tutor</span>{' '}
              in Mumbai
            </h1>
            <p className="text-lg md:text-xl text-blue-100 mb-8 leading-relaxed max-w-xl">
              Connect with qualified tutors across Mumbai, Thane, Navi Mumbai & beyond. Post your requirement free, or browse verified tutors instantly.
            </p>
            <div className="flex flex-col sm:flex-row gap-3">
              <Link href="/tutors">
                <Button size="xl" className="bg-orange-500 hover:bg-orange-400 w-full sm:w-auto shadow-xl">
                  <Search className="w-5 h-5 mr-2" />
                  Find Tutors
                </Button>
              </Link>
              <Link href="/post-requirement">
                <Button size="xl" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-900 w-full sm:w-auto">
                  Post Requirement Free
                  <ChevronRight className="w-5 h-5 ml-1" />
                </Button>
              </Link>
            </div>
          </div>
        </div>

        {/* Stats bar */}
        <div className="relative bg-white/10 backdrop-blur border-t border-white/20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
              {[
                { label: 'Verified Tutors', value: '500+' },
                { label: 'Areas Covered', value: '40+' },
                { label: 'Happy Students', value: '2000+' },
                { label: 'Subjects', value: '25+' },
              ].map((stat) => (
                <div key={stat.label}>
                  <div className="text-2xl font-display font-bold text-orange-300">{stat.value}</div>
                  <div className="text-sm text-blue-200">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="font-display text-3xl md:text-4xl font-bold text-blue-950 mb-3">How It Works</h2>
            <p className="text-gray-500 max-w-xl mx-auto">Simple, fast, and free for students. Teachers pay only to unlock contact details.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { icon: BookOpen, title: 'Post Your Requirement', desc: 'Students post their tutor requirements for free — subject, class, area, and budget.', color: 'bg-blue-50 text-blue-600', step: '01' },
              { icon: Search, title: 'Browse Tutors', desc: 'Tutors browse all requirements by subject, class, and location filters.', color: 'bg-orange-50 text-orange-600', step: '02' },
              { icon: Users, title: 'Connect & Learn', desc: 'Tutors unlock contact details for ₹500 and connect with students directly.', color: 'bg-green-50 text-green-600', step: '03' },
            ].map((item) => (
              <div key={item.step} className="relative bg-white rounded-2xl p-8 shadow-sm border border-gray-100 card-hover">
                <div className="absolute -top-3 -right-3 w-10 h-10 bg-blue-950 text-white rounded-full flex items-center justify-center text-xs font-bold font-display">
                  {item.step}
                </div>
                <div className={`w-14 h-14 rounded-2xl ${item.color} flex items-center justify-center mb-5`}>
                  <item.icon className="w-7 h-7" />
                </div>
                <h3 className="font-display text-xl font-semibold text-blue-950 mb-2">{item.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Subjects Grid */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-10">
            <div>
              <h2 className="font-display text-3xl font-bold text-blue-950">Popular Subjects</h2>
              <p className="text-gray-500 mt-1">Find tutors for any subject</p>
            </div>
            <Link href="/tutors" className="text-orange-500 font-medium text-sm flex items-center gap-1 hover:gap-2 transition-all">
              View all <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {featuredSubjects.map((subject) => (
              <Link
                key={subject}
                href={`/tutors?subject=${encodeURIComponent(subject)}`}
                className="group flex items-center gap-3 p-4 rounded-xl border border-gray-100 hover:border-orange-200 hover:bg-orange-50 transition-all"
              >
                <div className="w-8 h-8 rounded-lg bg-orange-100 group-hover:bg-orange-200 flex items-center justify-center transition-colors">
                  <BookOpen className="w-4 h-4 text-orange-600" />
                </div>
                <span className="text-sm font-medium text-gray-700 group-hover:text-orange-700 transition-colors">{subject}</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Areas */}
      <section className="py-16 bg-blue-950 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h2 className="font-display text-3xl font-bold mb-2">We Cover All of Mumbai</h2>
            <p className="text-blue-300">From Virar to Panvel, we&apos;ve got every corner covered</p>
          </div>
          <div className="flex flex-wrap justify-center gap-2">
            {featuredAreas.map((area) => (
              <Link
                key={area}
                href={`/tutors?area=${encodeURIComponent(area)}`}
                className="inline-flex items-center gap-1.5 bg-white/10 hover:bg-orange-500 border border-white/20 hover:border-orange-400 text-white text-sm font-medium px-4 py-2 rounded-full transition-all"
              >
                <MapPin className="w-3.5 h-3.5" />
                {area}
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="font-display text-3xl md:text-4xl font-bold text-blue-950 mb-3">Why Bombay Home Tutors?</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: Shield, title: 'Verified Tutors', desc: 'All teacher profiles are reviewed and approved by our admin team.', color: 'text-blue-600 bg-blue-50' },
              { icon: Star, title: 'Best in Class', desc: 'Experienced tutors from top colleges and institutions across Mumbai.', color: 'text-orange-600 bg-orange-50' },
              { icon: MapPin, title: 'Local Experts', desc: 'Tutors who know your area and can reach you quickly for home visits.', color: 'text-green-600 bg-green-50' },
              { icon: GraduationCap, title: 'All Classes', desc: 'From Nursery to Post-Graduation and competitive exams like JEE & NEET.', color: 'text-purple-600 bg-purple-50' },
            ].map((item) => (
              <div key={item.title} className="text-center p-6 rounded-2xl border border-gray-100">
                <div className={`w-14 h-14 rounded-2xl ${item.color} flex items-center justify-center mx-auto mb-4`}>
                  <item.icon className="w-7 h-7" />
                </div>
                <h3 className="font-display font-semibold text-blue-950 mb-2">{item.title}</h3>
                <p className="text-sm text-gray-500 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-gradient-to-br from-orange-500 to-orange-600 text-white">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">Ready to Start Learning?</h2>
          <p className="text-orange-100 mb-8 text-lg">Join thousands of students and tutors on Mumbai&apos;s leading tutoring platform.</p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link href="/register">
              <Button size="xl" className="bg-white text-orange-600 hover:bg-orange-50 shadow-xl w-full sm:w-auto">
                Register as Tutor
              </Button>
            </Link>
            <Link href="/post-requirement">
              <Button size="xl" variant="outline" className="border-white text-white hover:bg-white/10 w-full sm:w-auto">
                Post Requirement Free
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
