import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import dbConnect from '@/lib/dbConnect'
import StudentRequirement from '@/models/StudentRequirement'

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    const user = session.user as any

    await dbConnect()
    const { searchParams } = new URL(req.url)

    // Teachers see all active requirements (masked contact)
    // Students see only their own
    if (user.role === 'teacher') {
      const subject = searchParams.get('subject')
      const area = searchParams.get('area')
      const filter: any = { isActive: true }
      if (subject) filter.subject = new RegExp(subject, 'i')
      if (area) filter.area = new RegExp(area, 'i')

      const requirements = await StudentRequirement.find(filter)
        .sort({ createdAt: -1 })
        .lean()

      // Import TeacherProfile to check which ones are unlocked
      const TeacherProfile = (await import('@/models/TeacherProfile')).default
      const profile = await TeacherProfile.findOne({ userId: user.id }).lean()
      const unlocked = profile?.unlockedRequirements?.map((id: any) => id.toString()) || []

      const masked = requirements.map((r) => {
        const isUnlocked = unlocked.includes(r._id.toString())
        return {
          _id: r._id,
          subject: r.subject,
          class: r.class,
          area: r.area,
          budget: r.budget,
          teachingMode: r.teachingMode,
          description: r.description,
          createdAt: r.createdAt,
          isUnlocked,
          contact: isUnlocked ? r.contact : null,
          name: isUnlocked ? r.name : null,
        }
      })
      return NextResponse.json({ requirements: masked })
    }

    // Student: own requirements
    const requirements = await StudentRequirement.find({ userId: user.id })
      .sort({ createdAt: -1 })
      .lean()
    return NextResponse.json({ requirements })
  } catch (err) {
    console.error(err)
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    const user = session.user as any
    if (user.role !== 'student') return NextResponse.json({ error: 'Only students can post requirements' }, { status: 403 })

    await dbConnect()
    const data = await req.json()
    const { subject, classLevel, area, budget, contact, name, description, teachingMode } = data

    if (!subject || !classLevel || !area || !budget || !contact || !name) {
      return NextResponse.json({ error: 'All required fields must be filled' }, { status: 400 })
    }

    const requirement = await StudentRequirement.create({
      userId: user.id,
      subject,
      class: classLevel,
      area,
      budget: Number(budget),
      contact,
      name,
      description,
      teachingMode,
    })

    return NextResponse.json({ success: true, requirement })
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'Server error' }, { status: 500 })
  }
}
