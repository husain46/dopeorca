import { NextRequest, NextResponse } from 'next/server'
import dbConnect from '@/lib/dbConnect'
import User from '@/models/User'

export async function POST(req: NextRequest) {
  try {
    await dbConnect()
    const { name, email, password, role, phone } = await req.json()

    if (!name || !email || !password || !role) {
      return NextResponse.json({ error: 'All fields are required' }, { status: 400 })
    }

    if (password.length < 6) {
      return NextResponse.json({ error: 'Password must be at least 6 characters' }, { status: 400 })
    }

    const existing = await User.findOne({ email: email.toLowerCase() })
    if (existing) {
      return NextResponse.json({ error: 'Email already registered' }, { status: 409 })
    }

    // Students are auto-approved; teachers need admin approval
    const isApproved = role === 'student'

    const user = await User.create({
      name,
      email: email.toLowerCase(),
      password,
      role,
      phone,
      isApproved,
    })

    return NextResponse.json({
      success: true,
      message:
        role === 'teacher'
          ? 'Account created. Awaiting admin approval.'
          : 'Account created successfully.',
      userId: user._id,
    })
  } catch (err: any) {
    console.error('Register error:', err)
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}
