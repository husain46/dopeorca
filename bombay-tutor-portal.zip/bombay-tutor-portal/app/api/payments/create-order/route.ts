import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import dbConnect from '@/lib/dbConnect'
import Payment from '@/models/Payment'
import { createOrder } from '@/lib/razorpay'
import { UNLOCK_FEE } from '@/lib/utils'

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    const user = session.user as any
    if (user.role !== 'teacher') return NextResponse.json({ error: 'Only teachers can unlock requirements' }, { status: 403 })

    await dbConnect()
    const { requirementId } = await req.json()
    if (!requirementId) return NextResponse.json({ error: 'requirementId is required' }, { status: 400 })

    // Check if already unlocked
    const TeacherProfile = (await import('@/models/TeacherProfile')).default
    const profile = await TeacherProfile.findOne({ userId: user.id })
    if (profile?.unlockedRequirements?.map((id: any) => id.toString()).includes(requirementId)) {
      return NextResponse.json({ error: 'Already unlocked' }, { status: 409 })
    }

    const amount = Number(process.env.UNLOCK_FEE) || UNLOCK_FEE
    const order = await createOrder(amount)

    await Payment.create({
      userId: user.id,
      requirementId,
      razorpayOrderId: order.id,
      amount,
      status: 'created',
    })

    return NextResponse.json({
      orderId: order.id,
      amount: order.amount,
      currency: order.currency,
      key: process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID,
    })
  } catch (err: any) {
    console.error('Create order error:', err)
    return NextResponse.json({ error: err.message || 'Server error' }, { status: 500 })
  }
}
