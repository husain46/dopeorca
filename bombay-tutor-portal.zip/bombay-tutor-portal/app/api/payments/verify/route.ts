import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import dbConnect from '@/lib/dbConnect'
import Payment from '@/models/Payment'
import crypto from 'crypto'

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    const user = session.user as any

    await dbConnect()
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature, requirementId } = await req.json()

    // Verify signature
    const body = razorpay_order_id + '|' + razorpay_payment_id
    const expectedSignature = crypto
      .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET!)
      .update(body)
      .digest('hex')

    if (expectedSignature !== razorpay_signature) {
      await Payment.findOneAndUpdate(
        { razorpayOrderId: razorpay_order_id },
        { status: 'failed' }
      )
      return NextResponse.json({ error: 'Payment verification failed' }, { status: 400 })
    }

    // Update payment record
    await Payment.findOneAndUpdate(
      { razorpayOrderId: razorpay_order_id },
      { razorpayPaymentId: razorpay_payment_id, razorpaySignature: razorpay_signature, status: 'paid' }
    )

    // Unlock the requirement for this teacher
    const TeacherProfile = (await import('@/models/TeacherProfile')).default
    await TeacherProfile.findOneAndUpdate(
      { userId: user.id },
      { $addToSet: { unlockedRequirements: requirementId } }
    )

    return NextResponse.json({ success: true, message: 'Payment verified and requirement unlocked!' })
  } catch (err: any) {
    console.error('Verify error:', err)
    return NextResponse.json({ error: err.message || 'Server error' }, { status: 500 })
  }
}
