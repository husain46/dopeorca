import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import dbConnect from '@/lib/dbConnect'
import Payment from '@/models/Payment'

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    const user = session.user as any

    await dbConnect()

    const filter = user.role === 'admin' ? {} : { userId: user.id }
    const payments = await Payment.find(filter)
      .sort({ createdAt: -1 })
      .populate('userId', 'name email')
      .populate('requirementId', 'subject class area')
      .lean()

    return NextResponse.json({ payments })
  } catch (err) {
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}
