import { NextRequest, NextResponse } from 'next/server'
import dbConnect from '@/lib/dbConnect'
import User from '@/models/User'
import TeacherProfile from '@/models/TeacherProfile'

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    await dbConnect()
    const profile = await TeacherProfile.findById(params.id).lean()
    if (!profile) return NextResponse.json({ error: 'Not found' }, { status: 404 })

    const user = await User.findById(profile.userId).lean()
    if (!user || !user.isApproved) return NextResponse.json({ error: 'Not found' }, { status: 404 })

    return NextResponse.json({
      _id: profile._id,
      name: user.name,
      subjects: profile.subjects,
      classes: profile.classes,
      areas: profile.areas,
      experience: profile.experience,
      fees: profile.fees,
      teachingMode: profile.teachingMode,
      bio: profile.bio,
      qualification: profile.qualification,
      gender: profile.gender,
    })
  } catch (err) {
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}
