import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import dbConnect from '@/lib/dbConnect'
import TeacherProfile from '@/models/TeacherProfile'

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    const user = session.user as any

    await dbConnect()
    const profile = await TeacherProfile.findOne({ userId: user.id }).lean()
    return NextResponse.json({ profile })
  } catch (err) {
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    const user = session.user as any
    if (user.role !== 'teacher') return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

    await dbConnect()
    const data = await req.json()

    const profile = await TeacherProfile.findOneAndUpdate(
      { userId: user.id },
      { ...data, userId: user.id },
      { upsert: true, new: true, runValidators: true }
    )

    return NextResponse.json({ success: true, profile })
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'Server error' }, { status: 500 })
  }
}
