import { NextRequest, NextResponse } from 'next/server'
import dbConnect from '@/lib/dbConnect'
import User from '@/models/User'
import TeacherProfile from '@/models/TeacherProfile'

export async function GET(req: NextRequest) {
  try {
    await dbConnect()
    const { searchParams } = new URL(req.url)
    const subject = searchParams.get('subject')
    const area = searchParams.get('area')
    const classLevel = searchParams.get('class')
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '12')

    const profileFilter: Record<string, any> = {}
    if (subject) profileFilter.subjects = { $in: [new RegExp(subject, 'i')] }
    if (area) profileFilter.areas = { $in: [new RegExp(area, 'i')] }
    if (classLevel) profileFilter.classes = { $in: [new RegExp(classLevel, 'i')] }

    const total = await TeacherProfile.countDocuments(profileFilter)
    const profiles = await TeacherProfile.find(profileFilter)
      .skip((page - 1) * limit)
      .limit(limit)
      .lean()

    const userIds = profiles.map((p) => p.userId)
    const users = await User.find({ _id: { $in: userIds }, isApproved: true }).lean()
    const userMap = new Map(users.map((u) => [u._id.toString(), u]))

    const tutors = profiles
      .filter((p) => userMap.has(p.userId.toString()))
      .map((p) => {
        const user = userMap.get(p.userId.toString())!
        return {
          _id: p._id,
          userId: p.userId,
          name: user.name,
          subjects: p.subjects,
          classes: p.classes,
          areas: p.areas,
          experience: p.experience,
          fees: p.fees,
          teachingMode: p.teachingMode,
          bio: p.bio,
          qualification: p.qualification,
          gender: p.gender,
        }
      })

    return NextResponse.json({ tutors, total, page, pages: Math.ceil(total / limit) })
  } catch (err) {
    console.error(err)
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}
