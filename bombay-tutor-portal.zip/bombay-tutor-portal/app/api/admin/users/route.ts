import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import dbConnect from '@/lib/dbConnect'
import User from '@/models/User'
import TeacherProfile from '@/models/TeacherProfile'

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    const user = session?.user as any
    if (!session || user?.role !== 'admin') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    await dbConnect()
    const { searchParams } = new URL(req.url)
    const role = searchParams.get('role')

    const filter: any = { role: { $ne: 'admin' } }
    if (role) filter.role = role

    const users = await User.find(filter).sort({ createdAt: -1 }).lean()
    return NextResponse.json({ users })
  } catch (err) {
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}
