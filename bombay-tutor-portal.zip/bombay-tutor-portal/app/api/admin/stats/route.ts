import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import dbConnect from '@/lib/dbConnect'
import User from '@/models/User'
import StudentRequirement from '@/models/StudentRequirement'
import Payment from '@/models/Payment'

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || (session.user as any)?.role !== 'admin') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    await dbConnect()
    const [teachers, students, pendingTeachers, requirements, payments, totalRevenue] = await Promise.all([
      User.countDocuments({ role: 'teacher' }),
      User.countDocuments({ role: 'student' }),
      User.countDocuments({ role: 'teacher', isApproved: false }),
      StudentRequirement.countDocuments({ isActive: true }),
      Payment.countDocuments({ status: 'paid' }),
      Payment.aggregate([{ $match: { status: 'paid' } }, { $group: { _id: null, total: { $sum: '$amount' } } }]),
    ])

    return NextResponse.json({
      teachers,
      students,
      pendingTeachers,
      requirements,
      payments,
      totalRevenue: totalRevenue[0]?.total || 0,
    })
  } catch (err) {
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}
